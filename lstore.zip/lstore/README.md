Group Name: The Data Avengers

Grading: Our group chose to be graded 100% on the auto-grader

Extra Changes: We added 4 new aggregation methods to query.py: max, min, count, avg

Attribution section:
- Karim Shami:
    - 25%
    - System Architect
- Leif Good-Olson:
    - 25%
    - Data Model Developer
- Matthew Abalos:
    - 20%
    - Bufferpool Management Developer
- Sri Lakshmi:
    - 15%
    - Query Interface Developer
- Kavya Sasikumar:
    - 15%
    - Tester
