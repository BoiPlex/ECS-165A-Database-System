Group Name: The Data Avengers

Grading: Our group chose to be graded 50% on the auto-grader

Attribution section:
- Karim Shami:
    - 25%
    - System Architect
    - Designed the disk/bufferpool/merge and worked on them
- Leif Good-Olson:
    - 25%
    - Merge Developer
    - Worked on the merge and all other parts of the project
- Matthew Abalos:
    - 17.5%
    - Bufferpool Developer
    - Created the bufferpool and repurposed the code to use it
- Kavya Sasikumar:
    - 17.5%
    - Disk Developer
    - Developed the disk read/write operations
- Sri Lakshmi:
    - 15%
    - Tester
    - Debugged the code to pass test cases